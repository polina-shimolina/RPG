﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace miniRPG3
{
    class Team
    {
        public string Name;
        public Hero1 hero1;
        public Hero2 hero2;
        public Hero3 hero3;
        public bool Alive;
        public Team(string name, Hero1 hero1, Hero2 hero2, Hero3 hero3)
        {
            Console.WriteLine("Придумай название своей команды:");
            name = Console.ReadLine();
            Console.WriteLine(hero1);
            Console.WriteLine(hero2);
            Console.WriteLine(hero3);

        }
        void AliveHeroes()
        {
            Hero1 hero1 = new Hero1();
            Hero2 hero2 = new Hero2();
            Hero3 hero3 = new Hero3();
            if ((hero1.HP == 0) && (hero2.HP == 0) && (hero3.HP == 0)){
                Alive = false;
            } else {
                Alive = true;
            }
        }
    }
}
